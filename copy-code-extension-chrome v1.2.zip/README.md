TODO: 
-more websites
-hide the icon and show when hover the code
-create a build script
